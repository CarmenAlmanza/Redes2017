#! /usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.path.insert(0,"./Code")
sys.path.insert(0,"./Constants")
from PyQt4 import QtGui, QtCore
from PyQt4.QtGui import QWidget, QLabel, QMessageBox
from usuario import Usuario
from CalculatorWindow import CalculatorWindow
from AlertWindow import AlertWindow
import Constants

LOGIN_WIDTH = 350
LOGIN_HEIGTH = 120
DEFAULT_POSTION_X =450
DEFAULT_POSTION_Y =450

#**************************************************
#Clase que representa la ventana de login, en donde
#se pide el usuario y password del contacto, se verifica 
#su acceso y si es acertado se le permite trabajar 
#con la calaculadora 
#**************************************************
class LoginWindow(QtGui.QWidget):

	def __init__(self ):
		super(LoginWindow, self).__init__()
		self.initUI()

	'''
	Funcion que inicia la ventana con todos sus componentes 
	'''
	def initUI(self):
		icon = QtGui.QIcon()
		icon.addPixmap(QtGui.QPixmap("Constants/login.png"))
		usuario_label = QtGui.QLabel('Usuario:', self)
		password_label = QtGui.QLabel('Password:', self)
		usuario_widget = QtGui.QLineEdit()
		password_widget = QtGui.QLineEdit()
		password_widget.setEchoMode(QtGui.QLineEdit.Password)
		#Definimos el boton para Ingresar
		login_button = QtGui.QPushButton('Ingresar')
		login_button.clicked.connect(lambda: self.access(usuario_widget, password_widget))
		login_button.setIcon(icon)
		#login_button.clicked.connect(lambda: self.alert("NO tienes acceso al sistema"))
		grid = QtGui.QGridLayout()
		grid.addWidget(usuario_label, 0, 0)
		grid.addWidget(password_label, 1, 0)
		grid.addWidget(usuario_widget, 0, 1,1,2)
		grid.addWidget(password_widget, 1, 1,1,2)
		grid.addWidget(login_button, 2, 2)
		self.setLayout(grid)
		self.setGeometry(DEFAULT_POSTION_X, DEFAULT_POSTION_Y, LOGIN_WIDTH, LOGIN_HEIGTH)
		self.setWindowTitle('Login')
		self.show()


	'''
	Funcion que pasa a texto claro las password de 
	nuestro archivo,pues se encuentran cifradas
	Esta funcion nos permite hacer una comparacion entre
	las password almacenadas y la que ingresa el usuario 
	para tener acceso
	'''
	def passDec(self, password):
		passworDesifrada = ''
		for letra in password:
			passworDesifrada+=chr((ord(letra)- Constants.c_desplazamiento))
		return passworDesifrada


	'''
	Funcion que dadas en Usuario y password, permite o no el acceso a los 
	contactos, se verifica que ya se encuentren en el archivo input.txt
	'''

	def access(self, usuario_widget=None, password_widget=None):
		usuario = usuario_widget.text()
		password = password_widget.text()
		users_list  = self.readDataBase()
		login_flag = False
		for user in users_list:
			pAux=self.passDec(user.password)
			if user.username == usuario and pAux == password:
				login_flag = True
		if login_flag :
			self.close()
			CalculatorWindow()
		else :
			AlertWindow("Acceso restringido" , "NO tienes acceso al sistema.").show()

	'''
	Funcion que crea una lista con los usuarios que se encientran en 
	el archivo y asi poder usar estos datos de forma eficiente
	'''
	def readDataBase(self):
		users_list = list()
		data_base = open('./Code/input.txt','r')
		info = data_base.readlines()
		for x in info:
			users_list.append(Usuario(x.split(': ',2)[1].split(' ',1)[0] , x.split(': ',2)[2].rstrip('\n')))
		data_base.close()
		return users_list

