#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from PyQt4 import QtGui, QtCore
from PyQt4.QtGui import QWidget, QLabel
from ScientificCalculator import ScientificCalculator
from AlertWindow import AlertWindow
from AddUserWindow import AddUserWindow


LOGIN_WIDTH = 350
LOGIN_HEIGTH = 250
DEFAULT_POSTION_X =450
DEFAULT_POSTION_Y =450

#**************************************************
#Clase que representa una calculadora grafica,ademas de 
#contar con las operaciones basicas nos muestra con un 
#boton la opcion de Agregar un usuario.
#**************************************************
class CalculatorWindow(QtGui.QWidget):

    def __init__(self ):
        super(CalculatorWindow, self).__init__()
        self.initUI()

    '''
    Funcion que inicia la ventana con todos sus componentes
    '''
    def initUI(self):
        
        add_user_button = QtGui.QPushButton("Agregar usuario")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("Constants/user.png"))
        add_user_button.setIcon(icon)
        operation_widget = QtGui.QLineEdit()
        clear_button = QtGui.QPushButton('C')
        one_button = QtGui.QPushButton('1')
        two_button = QtGui.QPushButton('2')
        three_button = QtGui.QPushButton('3')
        four_button = QtGui.QPushButton('4')
        five_button = QtGui.QPushButton('5')
        six_button = QtGui.QPushButton('6')
        seven_button = QtGui.QPushButton('7')
        eight_button = QtGui.QPushButton('8')
        nine_button = QtGui.QPushButton('9')
        zero_button = QtGui.QPushButton('0')
        dot_button = QtGui.QPushButton('.')
        sum_button = QtGui.QPushButton('+')
        substraction_button = QtGui.QPushButton('-')
        multiplication_button = QtGui.QPushButton('*')
        division_button = QtGui.QPushButton('/')
        module_button = QtGui.QPushButton('%')
        potency_button = QtGui.QPushButton('x^')
        result_button = QtGui.QPushButton('=')
        
        result_button.clicked.connect(lambda: self.operationResult(operation_widget))
        add_user_button.clicked.connect(lambda: self.addUserView())

        clear_button.clicked.connect(lambda: operation_widget.setText(""))
        one_button.clicked.connect(lambda: operation_widget.insert("1"))
        two_button.clicked.connect(lambda: operation_widget.insert("2"))
        three_button.clicked.connect(lambda: operation_widget.insert("3"))
        four_button.clicked.connect(lambda: operation_widget.insert("4"))
        five_button.clicked.connect(lambda: operation_widget.insert("5"))
        six_button.clicked.connect(lambda: operation_widget.insert("6"))
        seven_button.clicked.connect(lambda: operation_widget.insert("7"))
        eight_button.clicked.connect(lambda: operation_widget.insert("8"))
        nine_button.clicked.connect(lambda: operation_widget.insert("9"))
        zero_button.clicked.connect(lambda: operation_widget.insert("0"))
        dot_button.clicked.connect(lambda: operation_widget.insert("."))
        sum_button.clicked.connect(lambda: operation_widget.insert("+"))
        substraction_button.clicked.connect(lambda: operation_widget.insert("-"))
        multiplication_button.clicked.connect(lambda: operation_widget.insert("*"))
        division_button.clicked.connect(lambda: operation_widget.insert("/"))
        module_button.clicked.connect(lambda: operation_widget.insert("%"))
        potency_button.clicked.connect(lambda: operation_widget.insert("^"))

        grid = QtGui.QGridLayout()
        regex=QtCore.QRegExp("[0-9_+-_/_*_._%]+")
        validator = QtGui.QRegExpValidator(regex)
        operation_widget.setValidator(validator)
        
        grid.addWidget(add_user_button, 0, 3)
        grid.addWidget(operation_widget, 1, 0, 1, 3)

        grid.addWidget(clear_button,1 ,3)
        grid.addWidget(module_button,6 ,2)
        grid.addWidget(potency_button,2 ,3)

        grid.addWidget(seven_button, 3, 0)
        grid.addWidget(eight_button, 3, 1)
        grid.addWidget(nine_button, 3, 2)
        grid.addWidget(division_button, 3, 3)

        grid.addWidget(four_button, 4, 0)
        grid.addWidget(five_button, 4, 1)
        grid.addWidget(six_button, 4, 2)
        grid.addWidget(multiplication_button, 4, 3)

        grid.addWidget(one_button, 5, 0)
        grid.addWidget(two_button, 5, 1)
        grid.addWidget(three_button, 5, 2)
        grid.addWidget(substraction_button, 5, 3)

        grid.addWidget(zero_button, 6, 0)
        grid.addWidget(dot_button, 6, 1)
        grid.addWidget(result_button, 7, 0, 1, 4)
        grid.addWidget(sum_button, 6, 3)
        
        self.setLayout(grid)
        self.setGeometry(DEFAULT_POSTION_X, DEFAULT_POSTION_Y, LOGIN_WIDTH, LOGIN_HEIGTH)
        self.setWindowTitle('Calculadora')
        self.show()



    '''
    Funcion que nos da el resultado de las operciones de la calcualdora
    Dependiendo que es lo que introduzca el usuario se utilizaran las 
    operciones implemtadas en ScientificCalculator.
    '''
    def operationResult(self, operation_widget=None):
        operation = operation_widget.text()
        try:
            if "/" in operation:
                operation_widget.setText(ScientificCalculator('/', operation.split('/',1)[0], operation.split('/',1)[1]).division())
            if "*" in operation:
                operation_widget.setText(ScientificCalculator('*', operation.split('*',1)[0], operation.split('*',1)[1]).multiplicacion())
            if "+" in operation:
                operation_widget.setText(ScientificCalculator('+', operation.split('+',1)[0], operation.split('+',1)[1]).suma())
            if "-" in operation:
                operation_widget.setText(ScientificCalculator('-', operation.split('-',1)[0], operation.split('-',1)[1]).resta())
            if "%" in operation:
                operation_widget.setText(ScientificCalculator('%', operation.split('%',1)[0], operation.split('%',1)[1]).modulo())
            if "^" in operation:
                operation_widget.setText(ScientificCalculator('^', operation.split('^',1)[0], operation.split('^',1)[1]).potencia())
        except (IndexError):
            AlertWindow("Error", "Ingrese una operacion binaria valida").show()
            operation_widget.setText("")

    
    '''
    Funcion que se ejecuta cuando en la calculadora se oprime 
    la opcion agredgar un usuario, nos mostrara una ventana para 
    relaizar dicha accion.
    '''
    def addUserView(self):
        AddUserWindow()


# **************************************************
#  Definicion de la funcion principal
#**************************************************
def main():
    app = QtGui.QApplication(sys.argv)
    mainWindow = CalculatorWindow()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
