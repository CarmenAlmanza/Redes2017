 #! /usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.path.insert(0,"./Constants")
import Constants
from PyQt4 import QtGui, QtCore
from PyQt4.QtGui import QWidget, QLabel
from usuario import Usuario


LOGIN_WIDTH = 350
LOGIN_HEIGTH = 150
DEFAULT_POSTION_X =450
DEFAULT_POSTION_Y =450

#**************************************************
#Clase que representa la ventana agregar un usuario
#nuevo en la lista de Usurios almacenada, 
#se pide usuario y password, el ususrio se almacena 
#como texto claro y el password con un cifrado Cesar.
#**************************************************
class AddUserWindow(QtGui.QWidget):

    def __init__(self ):
        super(AddUserWindow, self).__init__()
        self.initUI()


    '''
    Funcion que inicia la ventana con todos sus componentes
    '''
    def initUI(self):
        usuario_label = QtGui.QLabel('Usuario:', self)
        password_label = QtGui.QLabel('Password:', self)
        usuario_widget = QtGui.QLineEdit()
        password_widget = QtGui.QLineEdit()
        #Definimos el boton para agregar
        login_button = QtGui.QPushButton('Agregar Usuario')
        login_button.clicked.connect(lambda: self.addUser(usuario_widget, password_widget))
        grid = QtGui.QGridLayout()
        grid.addWidget(usuario_label, 0, 0)
        grid.addWidget(password_label, 1, 0)
        grid.addWidget(usuario_widget, 0, 1)
        grid.addWidget(password_widget, 1, 1)
        grid.addWidget(login_button, 3, 1)
        self.setLayout(grid)
        self.setGeometry(DEFAULT_POSTION_X, DEFAULT_POSTION_Y, LOGIN_WIDTH, LOGIN_HEIGTH)
        self.setWindowTitle('Nuevo Usuario')
        self.show()


    '''
    Funcion que agrega un usuario nuevo en el archivo input.txt
    se toman como atributos el usuario y password que ingresa 
    el usuario
    '''
    def addUser(self, usuario_widget=None, password_widget=None):
        
        usuario = str(usuario_widget.text())
        password = str(password_widget.text())
        passworCifrada = ''
        for car in password:
            passworCifrada+=chr((ord(car) + Constants.c_desplazamiento))
        archi=open('./Code/input.txt','a')
        archi.write('username : '+ usuario + ' password : '+ passworCifrada +'\n')
        archi.close()
        self.close()
        