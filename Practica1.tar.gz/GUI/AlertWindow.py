#! /usr/bin/env python
# -*- coding: utf-8 -*-
from PyQt4 import QtGui, QtCore
from PyQt4.QtGui import QWidget, QLabel, QMessageBox


#**************************************************
#Clase que representa la ventana de alerta, en donde
#se muestra un aviso de que el usuario no se encuentra
#y que el acceso es restringido.
#**************************************************
class AlertWindow(QtGui.QWidget):

	message = ""
	title = ""

	def __init__(self, title, message):
		super(AlertWindow, self).__init__()
		self.message = message
		self.title = title

	def show(self):
		QMessageBox.critical(self, self.title, self.message)