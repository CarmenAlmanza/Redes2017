#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys
sys.path.insert(0,"./GUI")
from LoginWindow import LoginWindow
from PyQt4 import QtGui, QtCore
from PyQt4.QtGui import QWidget, QLabel, QMessageBox

# **************************************************
#  Definicion de la funcion principal,
#  donde se ejecuta todo el programa, 
#  hace uso de las vistas que se encuentran 
#  en la carpeta GUI
#**************************************************
def main():
    app = QtGui.QApplication(sys.argv)
    mainWindow = LoginWindow()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()