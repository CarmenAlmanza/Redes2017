#! /usr/bin/env python
# -*- coding: utf-8 -*-

#**************************************************
#Clase que representa un usuario con los atibutos que 
#se requieren en en programa, tanto en las ventanas 
#como en los datos almacenados.
#**************************************************
class Usuario:

	username = ""
	password = ""

	def __init__(self, username, password):
		self.username = username
		self.password = password
   
   	def getUsername(self):
   		return self.username

   	def getPassword(self):
   		return self.password

   	def setUsername(self, username=None):
   		self.username = username

   	def setPassword(self, password=None):
   		self.password = password
   		