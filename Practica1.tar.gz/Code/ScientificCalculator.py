from Calculator import Calculator

#**************************************************
#Clase que representa una calculadora compleja, hereda 
#de calculadora, ademas cuenta con 4 aperaciones mas.
#**************************************************
class ScientificCalculator(Calculator):

	def __init__(self, operator, first_entry, second_entry):
		Calculator.__init__(self, operator, first_entry, second_entry)

	def multiplicacion(self):
		return str(float(self.first_entry) * float(self.second_entry))
		
	def division(self):
		return str(float(self.first_entry) / float(self.second_entry))

	def modulo(self):
		return str(float(self.first_entry) % float(self.second_entry))

	def potencia(self):
		return str(pow(float(self.first_entry),float(self.second_entry)))

