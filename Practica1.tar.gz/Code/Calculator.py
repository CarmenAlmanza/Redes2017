#**************************************************
#Clase que representa una calculadora, cuenta con las 
#dos operaciones basicas.
#**************************************************
class Calculator(object):

	operator = ""
	first_entry = ""
	second_entry = ""

	def __init__(self, operator, first_entry, second_entry):
		self.operator = operator
		self.first_entry = first_entry
		self.second_entry = second_entry

	
	def suma(self):
		return str(float(self.first_entry) + float(self.second_entry))

	
	def resta(self):
		return str(float(self.first_entry) - float(self.second_entry))