#Constante que nos dice en el cifrado 
#de las password el tamanio del desplazamiento
c_desplazamiento = 5 